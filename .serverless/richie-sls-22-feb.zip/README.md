# svcless-20240222

npm install -g serverless
sls -version
serverless -v


## Command to start the serverless 
sls offline start